const path = {
    dev: 'http://localhost:8000/api/',
    prod: 'https://app.rapihire.com/api/'
}

export const url = path.prod

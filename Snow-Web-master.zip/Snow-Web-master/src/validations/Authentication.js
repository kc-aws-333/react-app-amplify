import * as Yup from 'yup'

export const register_validation = Yup.object({
    first_name: Yup.string().required('Required'),
    last_name: Yup.string().required('Required'),
    email: Yup.string().email('Please enter a valid email').required('Required'),
    confirm_email: Yup.string().email().oneOf([Yup.ref('email'), null], 'Emails must match').required('Required'),
    password: Yup.string().min(6, 'Password must be at least 6 characters').required('Required'),
    confirm_password: Yup.string().oneOf([Yup.ref('password'), null], 'Passwords must match').required('Required')

})
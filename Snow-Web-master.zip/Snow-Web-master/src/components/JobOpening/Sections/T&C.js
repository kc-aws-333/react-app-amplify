import React from "react";

const styles = {
  tc: {
    width: "100%",
  },
  tc_text: {
    padding: "5px",
    border: "1px solid #445566",
  },
};

const TandC = (props) => {

  const handlePrev = e => {
    props.prevSection(e);
  }

  return (
    <div className="w-100">

      <a className="text-primary p-3" rel="noopener noreferrer" target='_blank' href={`https://rapihire.com/official_docs/terms&conditions.html`}> 
        Click here to view Terms and Conditions
      </a>  
      <div className="text-center">
        
        <button className="btn btn-light w-100" onClick={handlePrev}>
          Previous
        </button>

        <button onClick={props.handleApprove} className="btn btn-success w-100">
          Agree &amp; Accept
        </button>
      </div>
    </div>
  );
};

export default TandC;

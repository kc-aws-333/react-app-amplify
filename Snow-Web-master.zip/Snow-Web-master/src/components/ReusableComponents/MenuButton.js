import React from 'react'



const MenuButton = (props) => (

    <button 
        className="button__menu"
        style={{
          backgroundColor: props.is_active ? '#249afa' :'#ffffff',
          color: props.is_active ? '#ffffff' :'#839eaf',
        }}  
        type={props.type} onClick={props.handle_click} 
    >
    {props.label}
    </button>

)

export default MenuButton;
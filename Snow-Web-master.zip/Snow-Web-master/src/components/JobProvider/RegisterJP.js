import React, { useState } from "react";
import userService from "../../services/user";
import { errorAlert, successAlert } from "../../reducers/alertReducer";
import { useDispatch } from "react-redux";
import Popup from "../CoreComponents/Popup";
import { useHistory } from "react-router-dom";

import { Link } from "react-router-dom";
import { sign_in_up } from "../../theme.js";

import FormikTextInput from "../ReusableComponents/FormikTextInput";

import { Formik, Form } from "formik";
import { register_validation } from "../../validations/Authentication";
import {
  set_loading_false,
  set_loading_true,
} from "../../reducers/loadingReducer";

import VisibilityIcon from "@material-ui/icons/Visibility";
import VisibilityOffIcon from "@material-ui/icons/VisibilityOff";
import FormikCheckBox from "../ReusableComponents/FormikCheckBox";

const RegisterJP = () => {
  const dispatch = useDispatch();
  const history = useHistory();
  // const [repeat_password, set_repeat_password] = useState('')


  const [show_password, set_show_password] = useState(false);

  const tooglePassword = (e) => {
    e.preventDefault();
    set_show_password(!show_password);
  };

  return (
    <div className="text-right mt-4">

        <Link to="/login" className=" p-5 ">
            Log in
        </Link>

      <div style={{marginTop:'1vh'}}/>

      <div className="form-width-size m-auto p-4 shadow text-left" >   

            <p className="font-weight-bold text-secondary h5 mb-4">
            Create an account - Job Provider
            </p>  

        <Formik
          initialValues={{
            first_name: "",
            last_name: "",
            email: "",
            confirm_email: "",
            password: "",
            confirm_password: "",
            accepted_terms: false
          }}
          validationSchema={register_validation}
          onSubmit={async (values, { setSubmitting, resetForm }) => {
            // resetForm()
            setSubmitting(false);
            dispatch(set_loading_true());
            const payload = {
              first_name: values.first_name,
              last_name: values.last_name,
              email: values.email,
              password: values.password,
            };

            try {
              await userService.createJP(payload);
              history.push("/login");
              dispatch(set_loading_false());

              dispatch(
                successAlert(
                  "You successfully registered! Please check the confirmation email we sent to your email address!"
                )
              );
              setTimeout(() => dispatch(errorAlert("")), 4000);
            } catch (exception) {
              dispatch(set_loading_false());
              dispatch(
                errorAlert("An account with this email already exists!")
              );
            }
          }}
        >
          {(props) => (
            <Form>
              <FormikTextInput name="first_name" label="First Name *" />
              <FormikTextInput name="last_name" label="Last Name *" />
              <FormikTextInput
                placeholder={"example@email.com"}
                name="email"
                label="Email *"
              />
              <FormikTextInput name="confirm_email" label="Repeat Email *" />
              <div className="pwd-container">
                <FormikTextInput
                  type={show_password ? "text" : "password"}
                  name="password"
                  label="Password *"
                />
                {show_password ? (
                  <VisibilityOffIcon
                    onClick={tooglePassword}
                    className="icon"
                  />
                ) : (
                  <VisibilityIcon onClick={tooglePassword} className="icon" />
                )}
              </div>
              <FormikTextInput
                type={show_password ? "text" : "password"}
                name="confirm_password"
                label="Repeat Password *"
              />

              <br />
           
              <div className="text-center">
                    
                <FormikCheckBox checked={props.values.accepted_terms} name='accepted_terms' />
                {' '}I Accept <a style={{color:'rgb(73,154,243)'}} rel="noopener noreferrer" target='_blank' href={`https://rapihire.com/official_docs/terms&conditions.html`}> Terms and Conditions </a>, including 
                <a style={{color:'rgb(73,154,243)'}} rel="noopener noreferrer" target='_blank' href={`https://rapihire.com/official_docs/privacy.html`}> Privacy Policy </a>, 
                <a style={{color:'rgb(73,154,243)'}} rel="noopener noreferrer" target='_blank' href={`https://rapihire.com/official_docs/cookies.html`}> Cookies Policy </a> and 
                <a style={{color:'rgb(73,154,243)'}} rel="noopener noreferrer" target='_blank' href={`https://rapihire.com/official_docs/eula.html`}> EULA </a> 

                <span className="invalid-feedback mt-4 mb-2">
                    * Please accept Terms and Conditions to register!
                </span>
                
                <button disabled={!props.values.accepted_terms} className="btn btn-primary w-50" type="submit">
                  {props.isSubmitting ? "Loading..." : "Register"}
                </button>
              </div>
            </Form>
          )}
        </Formik>
      </div>
    </div>
  );
};

export default RegisterJP;

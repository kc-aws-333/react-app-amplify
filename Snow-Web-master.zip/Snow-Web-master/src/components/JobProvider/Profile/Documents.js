import React from 'react'


const styles = {

    form:{
        width:'500px',
        borderRadius: '4px',
        border: 'solid 1px #ccd7df',
        backgroundColor:'#ffffff'
    },
    label:{
        margin:'20px',
        fontSize: '16px',
        color: '#445566',
        marginBottom:'5px'
    },
    value:{
        color: '#839eaf',
        fontSize: '16px',
        lineHeight: 1.5,
        marginLeft:'20px',
    },
    delete_label:{
        color:'#ee5566',
        fontSize: '16px',
        marginLeft:'20px'
    }
}



const Documents = () => {
  


    return (
        <form className='home-tab' >
           
                
                <div>
                    <p style={styles.label}>Tax Information</p> 
                    <p style={styles.value}>123 456 789</p>
                </div>
                <hr/>
                <div> 
                    <p style={styles.label}>Legal Agreements</p> 
                    <p style={styles.value}>NDAs, CDAs, MSAs etc</p>
                </div>
                
        </form>
    )
}

export default Documents
import { KeyboardArrowDownOutlined, KeyboardArrowUpOutlined } from '@material-ui/icons'
import React, { useEffect, useState } from 'react'
import { useDispatch } from 'react-redux'
import { errorAlert, successAlert } from '../../reducers/alertReducer'
import { get_companies } from '../../reducers/companyReducer'
import { set_loading_false, set_loading_true } from '../../reducers/loadingReducer'
import { update_user } from '../../reducers/userReducer'
import userService from '../../services/user'

const styles = {
    wait_div:{
        borderRadius:8,
        backgroundColor:'red',
        border:'none',
        textAlign:'center',
        width:'70%',
        margin:'auto',
        color:'white',
        fontWeight:700,
        padding:20
    },
    reasons_div: {
        backgroundColor: 'rgb(255, 117, 117)',
        textAlign: 'left',
        borderRadius:8,
    }
}

export const WaitForApprovalJP = () => {
    return (
        <>
        <div style={styles.wait_div}>
            To use our services, your profile needs to be approved by our back office. Meanwhile, you can still
            add job listings or/and modify your profile.
        </div>
        <br/>
        </>
    )
}

export const WaitForApprovalJS = () => {
    return (
        <>
        <div style={styles.wait_div}>
            To use our services, your profile needs to be approved by our back office. Meanwhile, you can still
            add interested positions or/and modify your profile.
        </div>
        <br/>
        </>
    )
}

export const ProfileDeclinedJS = ({user_id}) => {
    const dispatch = useDispatch()
    const [reasons, set_reasons] = useState([])
    const [show_reasons, set_show_reasons] = useState(false)
    

    const render_reasons = () => {
        return (
            <div style={styles.reasons_div}>
            <ul>
                {!reasons.length && 
                <li>The recruiter didn't leave any note!</li>
                }
                {reasons.map((reason, idx) => 
                    <li key={idx}>
                        <b>{reason.title}</b>
                        <br/>
                        <span style={{fontSize:14}} > - {reason.reason.length ? reason.reason : 'No notes' }</span>
                    </li>
                )}
            </ul>
            <KeyboardArrowUpOutlined onClick={()=>set_show_reasons(false)} style={{cursor:'pointer'}} fontSize='large'/>
            </div>
        )
    }

    const handle_resubmit = async (e) => {
        e.preventDefault()
        try {
            dispatch(set_loading_true())
            await userService.resubmit_profile_js(user_id)

            dispatch(successAlert('Successfully submitted profile for review!'))
            setTimeout(()=> {
            dispatch(successAlert(''))
            }, 4000)

            dispatch(set_loading_false())
            dispatch(update_user({}))
        }catch (err){
            dispatch(errorAlert('Problem re submitting profile! Please try again later!'))
            dispatch(set_loading_false())
        }
    }

    useEffect(()=> {
        if (user_id){
            userService.get_reasons_declined_js(user_id)
                .then(data => set_reasons(data['reasons_declined']))
                .catch(err => console.log(err))
        }
    },[user_id])


    return (
        <>
        <div style={styles.wait_div}>
            Your profile has been declined by our back office.
            Please update your information and click the button for approval.
            <br/>
            <button onClick={handle_resubmit} className='btn btn-primary w-50 mt-3 float-left' style={{  backgroundColor: 'rgb(255, 117, 117)' }}>
                Re-submit
            </button> <br/>
            {show_reasons 
            ? <span style={{cursor:'pointer'}} onClick={()=>set_show_reasons(false)} > Hide details <KeyboardArrowUpOutlined  fontSize='large'/> </span>
            : <span style={{cursor:'pointer'}} onClick={()=>set_show_reasons(true)} > View details <KeyboardArrowDownOutlined fontSize='large'/> </span>
            }
            <br/>
            { show_reasons && render_reasons()}
        </div>
        <br/>
        </>
    )
}

export const ProfileDeclinedJP = ({user_id}) => {
    const dispatch = useDispatch()
    const [reasons, set_reasons] = useState([])
    const [show_reasons, set_show_reasons] = useState(false)
    

    const render_reasons = () => {
        return (
            <div style={styles.reasons_div}>
            
            <ul>
                {!reasons.length && 
                <li>The recruiter didn't leave any note!</li>
                }
                {reasons.map((reason, idx) => 
                    <li key={idx}>
                        <b>{reason.title}</b>
                        <br/>
                        <span style={{fontSize:14}} > - {reason.reason.length ? reason.reason : 'No notes' }</span>
                    </li>
                )}
            </ul>
            <KeyboardArrowUpOutlined onClick={()=>set_show_reasons(false)} style={{cursor:'pointer'}} fontSize='large'/>
            </div>
        )
    }

    const handle_resubmit = async (e) => {
        e.preventDefault()
        try {
            dispatch(set_loading_true())
            await userService.resubmit_profile_jp(user_id)

            dispatch(successAlert('Successfully submitted profile for review!'))
            setTimeout(()=> {
            dispatch(successAlert(''))
            }, 4000)

            dispatch(set_loading_false())
            dispatch(get_companies({}))
        }catch (err){
            dispatch(errorAlert('Problem re submitting profile! Please try again later!'))
            dispatch(set_loading_false())
        }
    }
    
    useEffect(()=> {
        if (user_id){
            userService.get_reasons_declined_js(user_id)
                .then(data => set_reasons(data['reasons_declined']))
                .catch(err => console.log(err))
        }
    },[user_id])
    
    return (
        <>
        <div style={styles.wait_div}>
            Your profile has been declined by our back office.
            Please update your information and click the button for approval.
            <br/>
            <button onClick={handle_resubmit} className='btn btn-primary w-50 mt-3 float-left' style={{backgroundColor: 'rgb(255, 117, 117)' }}>
                Re-submit
            </button> <br/>
            {show_reasons 
            ? <span style={{cursor:'pointer'}} onClick={()=>set_show_reasons(false)} > Hide details <KeyboardArrowUpOutlined  fontSize='large'/> </span>
            : <span style={{cursor:'pointer'}} onClick={()=>set_show_reasons(true)} > View details <KeyboardArrowDownOutlined fontSize='large'/> </span>
            }
            <br/>
            { show_reasons && render_reasons()}
        </div>
        <br/>
        </>
    )
}
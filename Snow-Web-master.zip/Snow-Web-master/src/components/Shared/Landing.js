import React from "react";
import { useSelector } from "react-redux";
import { Redirect } from "react-router-dom";
import { Button } from "react-bootstrap";
import logo from "../../icons/logo.svg";

const styles = {
  employer_button: {
    borderRadius: "4px",
    backgroundColor: "#0099ee",
    border: "none",
    color: "white",
    marginRight: 20,
    padding: "15px",
  },
  job_seeker_button: {
    borderRadius: "4px",
    backgroundColor: "#ffffff",
    border: "none",
    color: "black",
    padding: "15px",

  },
  link: {
    textDecoration: "none",
    color: "white",
  },
  login: {
    padding: 10,
    border: "1px solid white",
    textAlign: "center",
    width: 100,
    position: "absolute",
    right: "5%",
  },
  header: {
    color: "white",
    fontSize: "36px",
    fontWeight: "bold",
  },
  div: {
    backgroundPosition: "center center",
    backgroundSize: "cover",
    height: "100vh",
    backgroundImage: `url(https://rapihiredocs1.s3.us-east-2.amazonaws.com/static/webpage/landing.png)`,
  },
  nav: {
    color: "white",
    paddingRight: 40,
    fontWeight: "bold",
    textAlign: "center",
  },
};

const Landing = () => {
  const user = useSelector(({ user }) => user);

  if (user) {
    if (user.is_job_seeker) return <Redirect push to="/js/myprofile" />;
    else return <Redirect push to="/jp" />;
  }

  return (
    <div style={styles.div}>
      <br />
      <div className="landing-nav">
        <img
          style={{ paddingLeft: 10, marginRight: 60 }}
          alt="raihire logo"
          src={logo}
        />
        {/* <a href='/' >Home</a>
                <a href='/' >Product</a>
                <a href='/' >Pricing</a>
                <a href='/' >About</a> */}
      </div>

      <div style={styles.login}>
        <a style={{ color: "white" }} href="/login">
          Sign In
        </a>
      </div>
      <div style={{ textAlign: "center", marginTop: "30vh" }}>
        <h2 style={styles.header}>Fast employment without job interviews</h2>
        <br />
        <div>
          <Button style={styles.employer_button}>
            <a style={{ color: "#fff", fontWeight: 700 }} href="/jp/register">
              {" "}
              Create employer account{" "}
            </a>{" "}
          </Button>
          <Button style={styles.job_seeker_button}>
            <a style={{ color: "black", fontWeight: 700 }} href="/js/register">
              {" "}
              Create job seeker account{" "}
            </a>{" "}
          </Button>
        </div>
        <br />
        {/* <p style={{ color: "white", fontWeight: 700 }}>Need Help?</p> */}
      </div>
    </div>
  );
};

export default Landing;

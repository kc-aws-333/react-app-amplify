import React, { useState } from "react";
import userService from "../../../services/user";
import ArrowBackIcon from "@material-ui/icons/ArrowBack";
import { Link } from "react-router-dom";
import SingleSkill from "../../Shared/SingleSkill";
import { job_listing } from "../../../theme";
import { useDispatch } from "react-redux";
import {
  set_loading_false,
  set_loading_true,
} from "../../../reducers/loadingReducer";
import { errorAlert, successAlert } from "../../../reducers/alertReducer";

const styles = {
  center_div: {
    width: 500,
    margin: "auto",
  },
  input: {
    width: 400,
    height: 35,
  },
  add: {
    height: 35,
    backgroundColor: "#009cee",
    color: "#fff",
    border: "none",
    marginLeft: 5,
    borderRadius: 5,
  },
  send: {
    backgroundColor: "#009cee",
    color: "#fff",
    border: "none",
    borderRadius: 5,
    width: 200,
    height: 35,
  },
};

const InviteReferral = () => {
  const dispatch = useDispatch();
  const [referrals, set_referrals] = useState([]);
  const [curr_email, set_curr_email] = useState("");

  const valid_email = (email) => {
    const re =
      /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(email);
  };

  const handle_add = (e) => {
    e.preventDefault();
    set_referrals([...referrals, curr_email]);
    set_curr_email("");
  };

  const handle_delete = (e, email) => {
    e.preventDefault();
    set_referrals(referrals.filter((em) => em !== email));
  };

  const handle_submit = (e) => {
    e.preventDefault();
    set_referrals([]);

    dispatch(set_loading_true());
    referrals.forEach((email) => {
      userService
        .create_referral({ email })
        .then(() => {
          dispatch(successAlert("Invitations sent!"));
          dispatch(set_loading_false());
        })
        .catch((err) => {
          dispatch(
            errorAlert(
              "You are trying to invite a user which is already registered at Rapihire. You can send invitation to other friends!"
            )
          );
          setTimeout(() => dispatch(errorAlert("")), 8000);
          dispatch(set_loading_false());
        });
    });
  };

  return (
    <div className="logged-in-container">
      <Link
        style={{ textDecoration: "none" }}
        to="/js/passiveincome"
        className="form_header"
      >
        <ArrowBackIcon
          style={{ marginBottom: 4, opacity: 0.6 }}
          fontSize="large"
        />{" "}
      </Link>

      <div style={styles.center_div}>
        <p style={{ color: "#445566", fontSize: 20, fontWeight: "bold" }}>
          Invite friends
        </p>
        <br />
        <label>Email</label>
        <br />
        <input
          style={styles.input}
          value={curr_email}
          onChange={(e) => set_curr_email(e.target.value)}
        />
        {valid_email(curr_email) && (
          <button onClick={handle_add} style={styles.add}>
            ADD
          </button>
        )}
        <br />
        <div style={job_listing.skill_list}>
          {referrals.map((email, index) => (
            <div key={index}>
              <SingleSkill label={email} key={email} delete={handle_delete} />
            </div>
          ))}
        </div>
        <div style={{ marginTop: 100, textAlign: "right" }}>
          {referrals.length > 0 && (
            <button onClick={handle_submit} style={styles.send}>
              Send Invite
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default InviteReferral;

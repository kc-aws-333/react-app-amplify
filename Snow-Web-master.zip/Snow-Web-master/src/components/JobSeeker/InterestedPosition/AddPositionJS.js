import React, { useState, useEffect } from "react";
import { Button } from "react-bootstrap";

import { useDispatch, useSelector } from "react-redux";

import { useHistory } from "react-router-dom";
import { add_interested_position } from "../../../reducers/interestedJobsReducer";
import InfoIcon from "@material-ui/icons/Info";

import { Formik, Form } from "formik";
import FormikTextInput from "../../ReusableComponents/FormikTextInput";
import FormikDateInput from "../../ReusableComponents/FormikDate";
import FormikDropDown from "../../ReusableComponents/FormikDropDown";
import { interested_position, interested_position_permanent } from "../../../validations/seeker_profile";

const styles = {
  button: {
    width: "100%",
    maxWidth: "800px",
    outlineStyle: "dotted",
    color: "#249afa",
  },
};

const JTL_CHOICES = [
  { value: "Hour", label: "Hour" },
  { value: "Day", label: "Day" },
  { value: "Week", label: "Week" },
  { value: "Month", label: "Month" },
  { value: "Piece of work", label: "Piece of work" },
];

const AddPosition = () => {
  const dispatch = useDispatch();
  const history = useHistory();

  const [positions, setPositions] = useState([]);
  const general = useSelector(({ general }) => general);
  const my_positions = useSelector(({ interestedJobs }) =>
    interestedJobs.map((job) => job.position.id)
  );
  const [job_all_length, set_job_all_length] = useState(
    "Either Permanent or Temporary"
  ); // permanent/temporary

  useEffect(() => {
    if (general.length !== 0) {
      const positionsArray = general.positions.map((pos) => {
        return { value: pos.id, label: pos.name };
      });
      setPositions(positionsArray);
    }
  }, [general]);

  const handleJobAllLength = (e) => {
    set_job_all_length(e.target.value);
  };

  return (
    <div className="logged-in-container">
      <div
        className='w-50 m-auto p-4 shadow'
        style={{ minWidth: "400px", maxWidth:"450px" }}
      >
        <p className="font-weight-bold text-secondary h5 mt-4 mb-5 text-left">Add Interested Positions </p>

        <Formik
          initialValues={{
            position: undefined,
            start_date: new Date(),
            // end_date:null,
            job_all_length: "",
            daily_desired_hours: 0,
            desired_rate_hour: 0,
            job_time_length: 0,
            job_time_length_quantity: 0,
          }}
          validationSchema={job_all_length !== 'Permanent' ? interested_position : interested_position_permanent }
          onSubmit={async (values, { setSubmitting, resetForm }) => {
            resetForm();
            setSubmitting(false);

            const payload = {
              position_id: values.position.id,
              start_date: values.start_date,
              end_date: values.end_date,
              job_time_length: values.job_time_length.name,
              daily_desired_hours: values.daily_desired_hours,
              desired_rate_hour: values.desired_rate_hour,
              job_all_length,
              job_time_length_quantity: values.job_time_length_quantity,
            };
            dispatch(add_interested_position(payload));
            history.push("/js/mypositions");
          }}
        >
          {(props) => (
            <Form>
              <FormikDropDown
                label={"Position you are interested in *"}
                options={positions.filter(
                  (pos) => !my_positions.includes(pos.value)
                )}
                name="position"
                placeholder={"Position"}
                value={positions.find(
                  (pos) => pos.value === props.values.position?.id
                )}
              />
              <FormikDateInput name="start_date" label="Start Date" />
              <br />
              <p className="text-input-label">
                Employment type?
                <InfoIcon style={{ float: "right" }} />
              </p>
              <input
                type="radio"
                value="Permanent"
                onChange={handleJobAllLength}
                checked={job_all_length === "Permanent"}
              />{" "}
              Permanent <br />
              <input
                type="radio"
                value="Temporary"
                onChange={handleJobAllLength}
                checked={job_all_length === "Temporary"}
              />{" "}
              Temporary <br />
              <input
                type="radio"
                value="Either Permanent or Temporary"
                onChange={handleJobAllLength}
                checked={job_all_length === "Either Permanent or Temporary"}
              />{" "}
              Either Permanent or Temporary <br />
              {/* <br/> */}
              {
                job_all_length !== 'Permanent' &&
              <>
              <FormikDropDown
                info={1}
                label={"Job Period *"}
                options={JTL_CHOICES}
                name="job_time_length"
              />
              <FormikTextInput
                info={1}
                label={"Unit *"}
                name="job_time_length_quantity"
              />
              </>
              }
              <div className="d-flex justify-content-between">
                <FormikTextInput
                  info={1}
                  name="daily_desired_hours"
                  type="number"
                  label="Daily hours *"
                />
                <FormikTextInput
                  info={1}
                  name="desired_rate_hour"
                  type="number"
                  label="Desired rate $/h *"
                />
              </div>
              <br />
              <br />
              <div className='text-center'>
                <button type="submit" className="btn btn-outline-primary w-100">
                  {props.isSubmitting ? "Loading..." : "Add position"}
                </button>
              </div>
            </Form>
          )}
        </Formik>
      </div>
    </div>
  );
};

export default AddPosition;

import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { Spinner, Badge } from "react-bootstrap";
import { Link } from "react-router-dom";

import { resume } from "../../../theme";

const ProfilePreviewJS = () => {
  const [all_skills, set_all_skills] = useState([]);

  // const user = useSelector( ({user}) => user )
  // const interested_positions = useSelector( ({interestedJobs}) => interestedJobs )
  const js = useSelector(({ job_seeker_info }) => job_seeker_info);
  const all_experiences = useSelector(
    ({ work_experiences }) => work_experiences
  );
  const all_educations = useSelector(({ education }) => education);
  const all_licenses = useSelector(({ licenses }) => licenses);
  const all_certifications = useSelector(
    ({ certifications }) => certifications
  );

  useEffect(() => {
    if (js) set_all_skills(js.skills);
  }, [js]);

  try {
    return (
      <div className="logged-in-container">
        <div className="resume-preview-container">

          <div className="resume-item-page-added">
            <p style={resume.titles}>
              PROFILE{" "}
              <Link
                to="/js/edit/profile"
                className="float-right"
              >
                edit
              </Link>
            </p>{" "}
            <br />
            <div className="text-muted">

              <img 
                className='profile-pic float-right'
                alt='Rapihire Profile img.'
                src={js.user.profile_image ? js.user.profile_image : 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAARkAAAC0CAMAAACXO6ihAAAAYFBMVEXR1dr////N09fS09j///3U1NrT1Nv//v/O1Nj7+/z39/jN0dfQ0dfa297u7/DW2Nzj5+nm6Orw7/He4eTo7vH5/v7r6u7k5Onv8/XZ2d7p6enz+Prb4ePw7/LW19jU2t2fgRK2AAAFqElEQVR4nO2d65aqMAyFWwoIlIvIcXS8jO//lke8zFGPqG0DgQ3fmr+zbPcKTZOmqRATExMTExMTExMTExMTQ0Kf/iYuhKEQnqeLqirLPC/LKhMe95j6gVLFPN/KW7YrxT0qdjxR5XEthu/7t9rE1ZjtJgjUbi2b+DPiFUeVcaMu0pf7cVpNoA5/mmU5sxij1Sj19U6Xo9XMxyeNt3vxHd1IUwTcI+2YdPOBLjV5yj3UblGJ9N+rciIrCuFF3APuCi/5UJYL23IkIYPa+p9ajLxuABfcg+4CvTCzmDPLCt5svLmNMMd1qcSWJlSZlTA1X9B+KlSf7GMarGaFbDXp+51vszIy4x5+ixQza2WOxLgbG527CHNchWHzWcpFmBrUOCoqXZVBjaM8a8f0C+hKs3MWRs6559AKntP6eyaB3NNoJ5d9ATI3bB8Y3PCN6LidPVMN4hGdacLqOTmiMhTCQOawDiTKIDqnSlL4phhPGf01KdPA4uOjlJcAxgcLkyODZrinQY8mcdpSHrgnQo52D7RBlRGTMk3QCDMpMykzKUOmDOB+hkaYGfc0WmBSpgkarx1zT4Meoj0wYERJpEzCPY8WoIkoEXN6OUkWAlAZbVeG9ghiOQTB2W2tDGA1BE2GHLHGMyJRBrAizUtJtnqAtfZ5QqLMOueeCDWJT5Mgh4sPSOogLsyhvieSOogLa6QaGrUnVCaGUsbqgkoDSyhlCEr0/imDtM58cNP2c7C+JsoVGEoZXREqkyApIwpCZaC8thA0xTMnsOIDHdMpg1Vh7zV3UzEmQ/LaIqLJdZ7gngsxdCElWt0rVcmVlCWWaxKCLKYsuGdCDU2CHG43I1zv3f7jAOWZTtCcHWBtZs7ob4Lq+g2YY7qg9o7abDO4ReaMSt3WGqj0wwMrp8AyB1amcFKm5B5+iyinkBvwTPsXt5BbAVaIXHEKuRMVco+/RVyyntg9wFxC7op78K2SOoTceAHTLcr+eAUvyL5D2V8/QIwlb/HedpJuArDc9R7bDFYO7ZlqbKNK7nG3T2DXOg67a+eFnUVYGQfI+98rNp3AMuCQ6Qa9NbWa0bT3jwxjhP1YhBH1pUoDq1mPYfW9opLPlcGqsXqHWhmYzKiUMUlhjctmTBriIh+m/I9RYDkuZUxS5dgpqweMlOEebKd42/eC/AJXS/QKo0w58gncf6QmVRHYhwYPhAbCwGeA7zAqggUtJ3qO0eEK1kWDNxgpM6rwwOgmGGCfoiZCZVYtAl0EcYfpA1cjyQKLWhkjYeQc/nzySmR47r8YzRJsXJQ2mmj7x1AYueEecUdo8zpG7iF3g83l7XGsNFZ1InN8aaLD0qJa2h+BNNnSxmQketGrSEvbmwe+TATshi9Iv50avs6qFDRMKPbSpUHa8X+TDO+TCsJoTvEWz7pIAyjDUaqkusqe4xyyBIG2fIn9GbM6++lhlO0pNbf11E3kAYCbiryKrCXEDRsx8J2fUpXJOa0By1IN2W50RfSe1TNmQ+28HShv15K9XInn0RBdeJq1aC+/2qzSoRmOd+hAl5M2wwrCdUHZqPOdNtVgtPG61KUmqQbSnbxjXWq2/Q81tUk9KyXrot/a6FY2vJ+R9/iL0l046hf0NCEaKNKe2lbEWR+zfqp0ythRcPz9vHfLzWlnx63MKfves52fx+SRntGfB9PCUP3wrrx3+HJWqbAfOT+HNhgtkfcjd0P6mAERyQ//QhyqHn1JN2Ts31NPhZF+xvtB9dViZC0Nq9UYFvZ2C+eRXbrhnv0rYr7vSX1zT/41e67mABHRy9DtwbUK2/es6ogZ210O6uNqamY8dflBH/e+j8QcXVBDRVEp1DYVw6aG8qmU9uC4T0f5vE6LdC+M+bUKHrpv0U369FuLdP90zxA80wnR8RpsehWSj64vYYaUrwW2SueVWQNZZmyb8f0F12dSCfuP2I0AAAAASUVORK5CYII='}
              />
              <p style={resume.titles}>Full Name</p>
              <p>
                {js.user.first_name} {js.user.last_name}{" "}
              </p>

              <p style={resume.titles}>Email</p>
              <p>{js.user.email} </p>

              <p style={resume.titles}>Address</p>
              <p>
                {" "}
                {js.address}, {js.city?.name}, {js.province?.name},{" "}
                {js.zip_code}, {js.country?.name}{" "}
              </p>
            </div>
          </div>

          <div className="resume-item-page-added">
            <p style={resume.titles}>
              EDUCATION{" "}
              <Link
                to="/js/edit/education"
                className="float-right"
              >
                edit
              </Link>{" "}
            </p>
            {all_educations.map((e) => (
              <div className="text-muted mt-2" key={e.id}>
                <p style={resume.titles}>{e.title}</p>
                <p style={{ padding: 0, margin: 0 }}>{e.year_achieved}</p>
                <p style={{ padding: 0 }}>
                  {e.institution}, {e.institution_location}{" "}
                </p>
              </div>
            ))}
          </div>

          <div className="resume-item-page-added">
            <p style={resume.titles}>
              WORK EXPERIENCES{" "}
              <Link
                to="/js/edit/workexperience"
                className="float-right"
              >
                edit
              </Link>
            </p>

            {all_experiences.map((e) => (
              <div key={e.id}>
                <table style={resume.experience_table}>
                  <tbody>
                    <tr>
                      <td style={{ ...resume.titles, marginBottom: "7px" }}>
                        {e.position.name}
                      </td>
                    </tr>

                    <tr>
                      <td>Company</td>
                      <td style={resume.e_table_info}>{e.company_name}</td>
                    </tr>

                    <tr>
                      <td>Start Date</td>
                      <td style={resume.e_table_info}>
                        {e.start_date
                          ? new Intl.DateTimeFormat("en-US").format(
                              Date.parse(e.start_date)
                            )
                          : "Not provided"}
                      </td>
                    </tr>

                    <tr>
                      <td>End Date</td>
                      <td style={resume.e_table_info}>
                        {e.end_date
                          ? new Intl.DateTimeFormat("en-US").format(
                              Date.parse(e.end_date)
                            )
                          : "Current Job"}
                      </td>
                    </tr>

                    <tr>
                      <td>Reference Name</td>
                      <td style={resume.e_table_info}>{e.contact_name}</td>
                    </tr>

                    <tr>
                      <td>Reference Email</td>
                      <td style={resume.e_table_info}>{e.contact_email}</td>
                    </tr>

                    <tr>
                      <td>Reference Phone</td>
                      <td style={resume.e_table_info}>{e.contact_phone}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            ))}
          </div>

          <div className="resume-item-page-added">
            <p style={resume.titles}>
              CERTIFICATIONS{" "}
              <Link
                to="/js/edit/certifications"
                className="float-right"
              >
                edit
              </Link>
            </p>
            {all_certifications.map((e) => (
              <div className="text-muted mt-2" key={e.id}>
                <p style={resume.titles}>{e.title}</p>
                <p style={{ padding: 0, margin: 0 }}>{e.year_achieved}</p>
                <p style={{ padding: 0 }}>
                  {e.institution}, {e.institution_location}{" "}
                </p>
              </div>
            ))}
          </div>

          <div className="resume-item-page-added">
            <p style={resume.titles}>
              LICENSES{" "}
              <Link
                to="/js/edit/licences"
                className="float-right text-sm"
              >
                edit
              </Link>
            </p>
            {all_licenses.map((e) => (
              <div className="text-muted mt-2" key={e.id}>
                <p style={resume.titles}>{e.title}</p>
                <p style={{ padding: 0, margin: 0 }}>{e.year_achieved}</p>
                <p style={{ padding: 0 }}>
                  {e.institution}, {e.institution_location}{" "}
                </p>
              </div>
            ))}
          </div>

          <div className="resume-item-page-added">
            <p style={resume.titles}>
              SKILLS{" "}
              <Link
                to="/js/edit/skills"
                className="float-right"
              >
                edit
              </Link>{" "}
            </p>
            {all_skills.map((s, i) => (
              <Badge
                pill
                key={i}
                style={{ fontSize: "14px", margin: "2px" }}
                variant="primary"
              >
                {s.name}
              </Badge>
            ))}
          </div>
        </div>
      </div>
    );
  } catch (error) {
    return (
      <div style={{ textAlign: "center", paddingTop: "100px" }}>
        <Spinner animation="border" />
      </div>
    );
  }
};

export default ProfilePreviewJS;

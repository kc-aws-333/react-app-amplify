import React, { useEffect, useState } from "react";
import { Link, Redirect } from "react-router-dom";
import { useSelector } from "react-redux";
import { Spinner, Badge } from "react-bootstrap";

import { logged_in } from "../../../theme";

const MyProfileJS = () => {
  const [all_skills, set_all_skills] = useState([]);

  const user = useSelector(({ user }) => user);
  const interested_positions = useSelector(
    ({ interestedJobs }) => interestedJobs
  );
  const js = useSelector(({ job_seeker_info }) => job_seeker_info);
  const all_experiences = useSelector(
    ({ work_experiences }) => work_experiences
  );
  const all_educations = useSelector(({ education }) => education);
  const all_licenses = useSelector(({ licenses }) => licenses);
  const all_certifications = useSelector(
    ({ certifications }) => certifications
  );

  useEffect(() => {
    if (js) set_all_skills(js.skills);
  }, [js]);

  if (!user) {
    return <Redirect push to="/login" />;
  }

  if (!js || !interested_positions) {
    return (
      <div style={{ textAlign: "center", paddingTop: "100px" }}>
        <Spinner animation="border" />
      </div>
    );
  }
  return (
    <div style={{ ...logged_in.container }}>
      <div
        style={{ width: "70%", margin: "auto", padding: 20, minWidth: "500px" }}
      >
        <h1>
          Your Profile{" "}
          <Link to="/js/profilepreview" style={{ fontSize: "16px" }}>
            Preview
          </Link>
        </h1>
        <hr />

        <h3>
          Personal Info{" "}
          <Link
            to="/js/createprofile"
            style={{ fontSize: "20px", float: "right" }}
          >
            edit
          </Link>
        </h3>

        <div style={{ margin: "20px", color: "grey" }}>
          <h4>Full Name</h4>
          <p>
            {user.first_name} {user.last_name}{" "}
          </p>
          <h4>Email</h4>
          <p>{user.email} </p>
          <h4>Phone</h4>
          <p>
            {js.telephone ? (
              js.telephone
            ) : (
              <Badge
                style={{ fontSize: "14px", margin: "2px" }}
                variant="danger"
              >
                not provided
              </Badge>
            )}{" "}
          </p>
          <h4>Country</h4>
          <p>
            {js.country ? (
              js.country.name
            ) : (
              <Badge
                style={{ fontSize: "14px", margin: "2px" }}
                variant="danger"
              >
                not provided
              </Badge>
            )}{" "}
          </p>
          <h4>City</h4>
          <p>
            {js.city ? (
              js.city.name
            ) : (
              <Badge
                style={{ fontSize: "14px", margin: "2px" }}
                variant="danger"
              >
                not provided
              </Badge>
            )}{" "}
          </p>
          <h4>Address</h4>
          <p>
            {js.address ? (
              js.address
            ) : (
              <Badge
                style={{ fontSize: "14px", margin: "2px" }}
                variant="danger"
              >
                not provided
              </Badge>
            )}{" "}
          </p>
        </div>

        <hr />

        <h3>
          Work Experiences{" "}
          <Link
            to="/js/edit/workexperience"
            style={{ fontSize: "20px", float: "right" }}
          >
            edit
          </Link>
        </h3>
        {all_experiences.map((e) => (
          <div style={{ margin: "20px", color: "grey" }} key={e.id}>
            {/* <hr/> */}

            <h4>{e.position.name}</h4>
            <p>
              {e.company_name}{" "}
              {e.is_current_job ? (
                <small>current job</small>
              ) : (
                <small>left job</small>
              )}
            </p>
          </div>
        ))}
        <hr />

        <h3>
          Education{" "}
          <Link
            to="/js/edit/education"
            style={{ fontSize: "20px", float: "right" }}
          >
            edit
          </Link>
        </h3>
        {all_educations.map((e) => (
          <div style={{ margin: "20px", color: "grey" }} key={e.id}>
            <hr />

            <h4>{e.title}</h4>
            <p>
              {e.institution} <small>{e.year_achieved}</small>
            </p>
          </div>
        ))}
        <hr />

        <h3>
          Licences{" "}
          <Link
            to="/js/edit/licences"
            style={{ fontSize: "20px", float: "right" }}
          >
            edit
          </Link>
        </h3>
        {all_licenses.map((e) => (
          <div style={{ margin: "20px", color: "grey" }} key={e.id}>
            <hr />

            <h4>{e.title}</h4>
            <p>
              {e.institution} <small>{e.year_achieved}</small>
            </p>
          </div>
        ))}
        <hr />

        <h3>
          Certifications{" "}
          <Link
            to="/js/edit/certifications"
            style={{ fontSize: "20px", float: "right" }}
          >
            edit
          </Link>
        </h3>
        {all_certifications.map((e) => (
          <div style={{ margin: "20px", color: "grey" }} key={e.id}>
            <hr />

            <h4>{e.title}</h4>
            <p>
              {e.institution} <small>{e.year_achieved}</small>
            </p>
          </div>
        ))}
        <hr />

        <h3>
          Skills{" "}
          <Link
            to="/js/edit/skills"
            style={{ fontSize: "20px", float: "right" }}
          >
            edit
          </Link>
        </h3>
        {all_skills.map((s) => (
          <Badge
            pill
            key={s.id}
            style={{ fontSize: "14px", margin: "2px" }}
            variant="primary"
          >
            {s.name}
          </Badge>
        ))}
        <hr />

        <h3>
          Interested Posittions{" "}
          <Link
            to="/js/mypositions"
            style={{ fontSize: "20px", float: "right" }}
          >
            edit
          </Link>
        </h3>
        {interested_positions.map((p) => (
          <div style={{ margin: "20px", color: "grey" }} key={p.id}>
            <hr />

            <h4>
              {p.position}{" "}
              <Badge style={{ fontSize: "14px" }} variant="secondary">
                Pending
              </Badge>{" "}
            </h4>
            <p>
              {p.job_all_length} <small>${p.desired_rate_hour}/h</small>
            </p>
          </div>
        ))}
        <hr />
      </div>
    </div>
  );
};

export default MyProfileJS;

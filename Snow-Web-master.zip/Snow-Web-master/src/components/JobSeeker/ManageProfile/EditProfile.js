import React, { useState, useEffect } from "react";
import Select from "react-select";
import { useDispatch, useSelector } from "react-redux";
import { Form, Spinner, Col } from "react-bootstrap";
import { update_js_info } from "../../../reducers/jsReducer";
import CustomButton from "../../ReusableComponents/CustomButton";
import {
  validate_canada_zip,
  validate_us_zip,
} from "../../../validations/GenralValidations";
import userService from '../../../services/user'
import { set_loading_false, set_loading_true } from "../../../reducers/loadingReducer";


const EditProfile = () => {
  const dispatch = useDispatch();
  const [js_info, set_js_info] = useState("");
  const [f_name, set_f_name] = useState("");
  const [l_name, set_l_name] = useState("");
  const [phone, set_phone] = useState("");
  const [city, set_city] = useState({ id: null, name: null });
  const [province, set_province] = useState({ id: null, name: null });
  const [country, set_country] = useState({ id: null, name: null });
  const [address, set_address] = useState("");
  const [zip_code, set_zip_code] = useState("");

  const [countries, setCountries] = useState([]);
  const [provinces, setProvinces] = useState([]);
  const [cities, setCities] = useState([]);

  const general = useSelector(({ general }) => general);
  const user = useSelector(({ user }) => user);

  const js_data = useSelector(({ job_seeker_info }) => job_seeker_info);
  const [zip_error, set_zip_error] = useState(false);
  const [show_error, set_show_error] = useState(false);

  const [img, set_img] = useState(null);

  const handle_file_select = (e) => {
    set_img(e.target.files[0]);
  };

  useEffect(() => {
    if (general.length !== 0) {
      const countryArray = general.countries.map((pos) => {
        return { value: pos.id, label: pos.name };
      });
      setCountries(countryArray);
      const cityArray = general.cities.map((pos) => {
        return { value: pos.id, label: pos.name, province: pos.province };
      });
      setCities(cityArray);
      const provinceArray = general.provinces.map((pos) => {
        return { value: pos.id, label: pos.name, country: pos.country };
      });
      setProvinces(provinceArray);
    }

    if (user && user.is_job_seeker && js_data) {
      set_js_info(js_data);
      // set_allowed_work(js_data.is_legally_work ? 'Yes' : 'No')
      set_f_name(user.first_name);
      set_l_name(user.last_name);
      set_phone(js_data.telephone ? js_data.telephone : "");
      set_address(js_data.address ? js_data.address : "");
      set_province(js_data.province ? js_data.province : "");
      set_city(js_data.city ? js_data.city : null);
      set_country(js_data.country ? js_data.country : null);
      set_zip_code(js_data.zip_code ? js_data.zip_code : "");
    }
  }, [user, general, js_data]);

  const handleTextField = (e, f) => {
    f(e.target.value);
  };

  if (!user || !js_info) {
    return (
      <div className="text-center">
        <Spinner style={{}} animation="border" />
      </div>
    );
  }

  const validate_form = () => {
    set_zip_error(
      country?.name === "USA"
        ? !validate_us_zip(zip_code)
        : !validate_canada_zip(zip_code)
    );
    return (
      address.length > 1 &&
      ((country?.name === "USA" && validate_us_zip(zip_code)) ||
        (country?.name === "Canada" && validate_canada_zip(zip_code))) &&
      city?.id &&
      province?.id &&
      country?.id &&
      phone.length < 16 &&
      phone.length > 9
    );
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (validate_form()) {
      set_show_error(false);
      try {
        const payload = {
          first_name: f_name,
          last_name: l_name,
          telephone: phone,
          address,
          zip_code,
          city_id: city.id,
          country_id: country.id,
          province_id: province.id,
        };
        
        const formData = new FormData();
        formData.append("file", img);

        if(img){
          dispatch(set_loading_true());

          userService
            .update_profile_image(formData)
            .then((data) =>  dispatch(update_js_info(payload, user)))
            .catch((err) => dispatch(set_loading_false()));
        }
        else dispatch(update_js_info(payload, user));
      } catch (error) {
        alert("Please make sure you filled all info ");
      }
    } else {
      set_show_error(true);
    }
  };

  const handleCountry = (choice) => {
    set_country({ id: choice.value, name: choice.label });
  };

  const handleCity = (choice) => {
    set_city({ id: choice.value, name: choice.label });
  };

  const handleProvince = (choice) => {
    set_province({ id: choice.value, name: choice.label });
  };

  return (
    <div className="logged-in-container">
      <div className="profile-edit-div">
        <p className="font-weight-bold text-secondary h5 mt-4">Personal Information</p>
        <hr />

        <div>
          <img 
            className='profile-pic'
            alt='Rapihire Profile img.'
            src={js_info.user.profile_image ? js_info.user.profile_image : 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAARkAAAC0CAMAAACXO6ihAAAAYFBMVEXR1dr////N09fS09j///3U1NrT1Nv//v/O1Nj7+/z39/jN0dfQ0dfa297u7/DW2Nzj5+nm6Orw7/He4eTo7vH5/v7r6u7k5Onv8/XZ2d7p6enz+Prb4ePw7/LW19jU2t2fgRK2AAAFqElEQVR4nO2d65aqMAyFWwoIlIvIcXS8jO//lke8zFGPqG0DgQ3fmr+zbPcKTZOmqRATExMTExMTExMTExMTQ0Kf/iYuhKEQnqeLqirLPC/LKhMe95j6gVLFPN/KW7YrxT0qdjxR5XEthu/7t9rE1ZjtJgjUbi2b+DPiFUeVcaMu0pf7cVpNoA5/mmU5sxij1Sj19U6Xo9XMxyeNt3vxHd1IUwTcI+2YdPOBLjV5yj3UblGJ9N+rciIrCuFF3APuCi/5UJYL23IkIYPa+p9ajLxuABfcg+4CvTCzmDPLCt5svLmNMMd1qcSWJlSZlTA1X9B+KlSf7GMarGaFbDXp+51vszIy4x5+ixQza2WOxLgbG527CHNchWHzWcpFmBrUOCoqXZVBjaM8a8f0C+hKs3MWRs6559AKntP6eyaB3NNoJ5d9ATI3bB8Y3PCN6LidPVMN4hGdacLqOTmiMhTCQOawDiTKIDqnSlL4phhPGf01KdPA4uOjlJcAxgcLkyODZrinQY8mcdpSHrgnQo52D7RBlRGTMk3QCDMpMykzKUOmDOB+hkaYGfc0WmBSpgkarx1zT4Meoj0wYERJpEzCPY8WoIkoEXN6OUkWAlAZbVeG9ghiOQTB2W2tDGA1BE2GHLHGMyJRBrAizUtJtnqAtfZ5QqLMOueeCDWJT5Mgh4sPSOogLsyhvieSOogLa6QaGrUnVCaGUsbqgkoDSyhlCEr0/imDtM58cNP2c7C+JsoVGEoZXREqkyApIwpCZaC8thA0xTMnsOIDHdMpg1Vh7zV3UzEmQ/LaIqLJdZ7gngsxdCElWt0rVcmVlCWWaxKCLKYsuGdCDU2CHG43I1zv3f7jAOWZTtCcHWBtZs7ob4Lq+g2YY7qg9o7abDO4ReaMSt3WGqj0wwMrp8AyB1amcFKm5B5+iyinkBvwTPsXt5BbAVaIXHEKuRMVco+/RVyyntg9wFxC7op78K2SOoTceAHTLcr+eAUvyL5D2V8/QIwlb/HedpJuArDc9R7bDFYO7ZlqbKNK7nG3T2DXOg67a+eFnUVYGQfI+98rNp3AMuCQ6Qa9NbWa0bT3jwxjhP1YhBH1pUoDq1mPYfW9opLPlcGqsXqHWhmYzKiUMUlhjctmTBriIh+m/I9RYDkuZUxS5dgpqweMlOEebKd42/eC/AJXS/QKo0w58gncf6QmVRHYhwYPhAbCwGeA7zAqggUtJ3qO0eEK1kWDNxgpM6rwwOgmGGCfoiZCZVYtAl0EcYfpA1cjyQKLWhkjYeQc/nzySmR47r8YzRJsXJQ2mmj7x1AYueEecUdo8zpG7iF3g83l7XGsNFZ1InN8aaLD0qJa2h+BNNnSxmQketGrSEvbmwe+TATshi9Iv50avs6qFDRMKPbSpUHa8X+TDO+TCsJoTvEWz7pIAyjDUaqkusqe4xyyBIG2fIn9GbM6++lhlO0pNbf11E3kAYCbiryKrCXEDRsx8J2fUpXJOa0By1IN2W50RfSe1TNmQ+28HShv15K9XInn0RBdeJq1aC+/2qzSoRmOd+hAl5M2wwrCdUHZqPOdNtVgtPG61KUmqQbSnbxjXWq2/Q81tUk9KyXrot/a6FY2vJ+R9/iL0l046hf0NCEaKNKe2lbEWR+zfqp0ythRcPz9vHfLzWlnx63MKfves52fx+SRntGfB9PCUP3wrrx3+HJWqbAfOT+HNhgtkfcjd0P6mAERyQ//QhyqHn1JN2Ts31NPhZF+xvtB9dViZC0Nq9UYFvZ2C+eRXbrhnv0rYr7vSX1zT/41e67mABHRy9DtwbUK2/es6ogZ210O6uNqamY8dflBH/e+j8QcXVBDRVEp1DYVw6aG8qmU9uC4T0f5vE6LdC+M+bUKHrpv0U369FuLdP90zxA80wnR8RpsehWSj64vYYaUrwW2SueVWQNZZmyb8f0F12dSCfuP2I0AAAAASUVORK5CYII='}
          />
        
          <br /><br/>
          <input
            onChange={handle_file_select}
            type="file"
            accept=".jpg, .jpeg, .png, .webp"
          />
          <br /><br/>
        </div>

        <Form onSubmit={handleSubmit} >
          <Form.Row>
            <Form.Group as={Col} controlId="fName">
              <Form.Label>First Name</Form.Label>
              <Form.Control
                value={f_name}
                disabled
                onChange={(e) => handleTextField(e, set_f_name)}
                type="text"
                placeholder="First Name"
              />
            </Form.Group>

            <Form.Group as={Col} controlId="lName">
              <Form.Label>Last Name</Form.Label>
              <Form.Control
                value={l_name}
                disabled
                onChange={(e) => handleTextField(e, set_l_name)}
                type="text"
                placeholder="Last Name"
              />
            </Form.Group>
          </Form.Row>

          {/* <hr/> */}
          <Form.Row>
            <Form.Group as={Col} controlId="email">
              <Form.Label>Email</Form.Label>
              <Form.Control
                value={user.email}
                disabled
                type="text"
                placeholder="Phone Number"
              />
            </Form.Group>

            <Form.Group as={Col} controlId="phone">
              <Form.Label>Phone</Form.Label>
              <Form.Control
                value={phone}
                onChange={(e) => handleTextField(e, set_phone)}
                type="text"
                placeholder="Phone Number"
              />
            </Form.Group>
          </Form.Row>
          {show_error && (phone.length > 15 || phone.length < 10) && (
            <p className="invalid-feedback">Enter a valid phone number</p>
          )}

          <hr />

          <Form.Group>
            Country
            <Select
              onChange={handleCountry}
              options={countries}
              value={countries.find((pos) => pos.value === country?.id)}
            />
          </Form.Group>
          {show_error && !country.id && (
            <p className="invalid-feedback">Required</p>
          )}

          <Form.Row>
            <Form.Group as={Col}>
              Province
              <Select
                onChange={handleProvince}
                options={provinces.filter(
                  (pos) => pos.country.id === country?.id
                )}
                value={provinces.find((pos) => pos.value === province?.id)}
              />
            </Form.Group>
            {show_error && !province.id && (
              <p className="invalid-feedback">Required</p>
            )}

            <Form.Group as={Col}>
              City
              <Select
                readonly
                value={cities.find((pos) => pos.value === city?.id)}
                onChange={handleCity}
                options={cities.filter((c) => c.province.id === province?.id)}
              />
            </Form.Group>
            {show_error && !city.id && (
              <p className="invalid-feedback">Required</p>
            )}
          </Form.Row>

          <Form.Row>
            <Form.Group as={Col} controlId="address">
              <Form.Label>Address</Form.Label>
              <Form.Control
                value={address}
                onChange={(e) => handleTextField(e, set_address)}
                type="text"
                placeholder="Address"
              />
            </Form.Group>

            <Form.Group as={Col} controlId="zip">
              <Form.Label>Zip Code</Form.Label>
              <Form.Control
                value={zip_code}
                onChange={(e) => handleTextField(e, set_zip_code)}
                type="text"
                placeholder="Address"
              />
            </Form.Group>
          </Form.Row>
          {show_error && zip_error && (
            <p className="invalid-feedback">Invalid ZIP for {country?.name}</p>
          )}
          {show_error && address.length < 2 && (
            <p className="invalid-feedback">Address Required</p>
          )}

          <hr />

          <div className="text-center">
            <button
              onSubmit={handleSubmit}
              type="submit"
              className="btn btn-primary w-75 m-2"
            >
              Update Profile
            </button>
          </div>
        </Form>
      </div>
    </div>
  );
};

export default EditProfile;

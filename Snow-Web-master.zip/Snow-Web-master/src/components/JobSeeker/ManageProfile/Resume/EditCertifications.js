import React, { useState } from "react";
import Togglable from "../../../Togglable";

import { useDispatch, useSelector } from "react-redux";
import {
  add_certification,
  delete_certification,
} from "../../../../reducers/jsResume/certificationReducer";
import { resume } from "../../../../theme";
import { Formik, Form } from "formik";
import FormikTextInput from "../../../ReusableComponents/FormikTextInput";

import { resume_item } from "../../../../validations/resume";
import { DeleteOutline } from "@material-ui/icons";
import EditIcon from "@material-ui/icons/Edit";
import UpdateCertification from "./UpdateResume/UpdateCertification";

const EditCertifications = () => {
  const dispatch = useDispatch();

  const all_certifications = useSelector(
    ({ certifications }) => certifications
  );

  const handle_delete = async (e, id) => {
    e.preventDefault();
    const ok = window.confirm("Are you sure you want to delete Certification?");
    if (ok) {
      dispatch(delete_certification(id));
    }
  };

  const [curr_certification, set_curr_certification] = useState(null);
  const [show_edit, set_show_edit] = useState(false);
  const handle_edit_click = (ev, e) => {
    ev.preventDefault();
    set_curr_certification(e);
    set_show_edit(true);
  };

  return (
    <div className="logged-in-container">
      {show_edit ? (
        <UpdateCertification
          set_show_edit={set_show_edit}
          certification={curr_certification}
        />
      ) : null}

      <div className="resume-item-page">
        <div>
          <p className="font-weight-bold text-secondary h5 mt-4"> My Certifications </p>

          {all_certifications.length > 0 ? (
            <div className="resume-item-page-added">
              {all_certifications.map((e) => (
                <div key={e.id}>
                  <hr />
                  <div className="mt-2 text-muted">
                    <p style={resume.titles}>
                      {e.title}
                      <button
                        onClick={(ev) => handle_delete(ev, e.id)}
                        style={resume.delete_button}
                      >
                        <DeleteOutline />
                      </button>
                      <button
                        onClick={(ev) => handle_edit_click(ev, e)}
                        style={resume.edit_button}
                      >
                        <EditIcon />
                      </button>
                    </p>
                    <p style={{ padding: 0, margin: 0 }}>{e.year_achieved}</p>
                    <p style={{ padding: 0 }}>
                      {e.institution}, {e.institution_location}{" "}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          ) : null}
        </div>

        <Togglable buttonlabel="Add new Certification">
          <div className="resume-item-page-form shadow">
            <Formik
              initialValues={{
                title: "",
                year_achieved: "",
                institution: "",
                institution_location: "",
              }}
              validationSchema={resume_item}
              onSubmit={async (values, { setSubmitting, resetForm }) => {
                // Reset Form
                resetForm();
                setSubmitting(false);

                const payload = {
                  title: values.title,
                  year_achieved: values.year_achieved,
                  institution: values.institution,
                  institution_location: values.institution_location,
                };
                dispatch(add_certification(payload));
              }}
            >
              {(props) => (
                <Form className="text-left m-auto w-100">
                  <FormikTextInput name="title" placeholder="Title" />
                  <FormikTextInput
                    name="year_achieved"
                    placeholder="Year Achieved"
                  />
                  <FormikTextInput
                    name="institution"
                    placeholder="Institution"
                  />
                  <FormikTextInput
                    name="institution_location"
                    placeholder="Institution Location"
                  />
                  <br />

                  <div className="text-center">
                    <button
                      className="btn btn-outline-primary w-100"
                      type="submit"
                    >
                      {props.isSubmitting ? "Loading.." : "Add"}
                    </button>
                  </div>
                </Form>
              )}
            </Formik>
          </div>
        </Togglable>
      </div>
    </div>
  );
};

export default EditCertifications;

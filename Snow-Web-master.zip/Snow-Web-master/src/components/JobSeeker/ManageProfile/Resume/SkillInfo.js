import { Button, Modal } from "react-bootstrap";
import React from "react";
import RangeSlider from "../../../ReusableComponents/RangeSlider";
import { resume } from "../../../../theme";

const styles = {
  slide: {
    width: "470px",
    backgroundColor: "#249afa",
  },
};

const SkillInfo = ({ skills, set_skills, set_show_edit, addSkills }) => {
  const handleClose = () => {
    set_show_edit(false);
  };

  const handle_range = (value, id) => {
    const updated_skill = skills.find((s) => s.id === id);
    const updated_skill_payload = {
      ...updated_skill,
      years_of_experience: value,
    };

    const updated_skills = skills.map((s) =>
      s.id === id ? updated_skill_payload : s
    );
    set_skills(updated_skills);
  };

  const handleSave = (e) => {
    e.preventDefault();
    addSkills();
    handleClose();
  };

  return (
    <Modal show={true} onHide={handleClose}>
      <Modal.Header closeButton>
        <Modal.Title>Years of experience</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        {skills.map((s) => (
          <div key={s.id}>
            <p>{s.name}</p>
            <RangeSlider
              style={styles.slide}
              maxValue={20}
              minValue={0}
              step={1}
              value={s.years_of_experience ? s.years_of_experience : 0}
              onChange={(value) => handle_range(value, s.id)}
            />{" "}
            <br />
            <br />
          </div>
        ))}
        <div style={{ textAlign: "center" }}>
          <Button onClick={handleSave} style={resume.add_button} variant="link">
            Save
          </Button>
        </div>
      </Modal.Body>
    </Modal>
  );
};

export default SkillInfo;

import React from "react";

import { Modal } from "react-bootstrap";
import { Form, Formik } from "formik";
import { resume_item } from "../../../../../validations/resume";
import FormikTextInput from "../../../../ReusableComponents/FormikTextInput";
import { useDispatch } from "react-redux";
import userService from "../../../../../services/user";
import { errorAlert, successAlert } from "../../../../../reducers/alertReducer";
import { init_certifications } from "../../../../../reducers/jsResume/certificationReducer";

const UpdateCertification = ({ certification, set_show_edit }) => {
  const dispatch = useDispatch();
  const handleClose = () => {
    set_show_edit(false);
  };
  return (
    <Modal show={true} onHide={handleClose}>
      <Modal.Header closeButton>
        <Modal.Title>Edit certification</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <Formik
          initialValues={{
            title: certification.title,
            year_achieved: certification.year_achieved,
            institution: certification.institution,
            institution_location: certification.institution_location,
          }}
          validationSchema={resume_item}
          onSubmit={async (values, { setSubmitting }) => {
            // Reset Form
            setSubmitting(false);
            const payload = {
              title: values.title,
              year_achieved: values.year_achieved,
              institution: values.institution,
              institution_location: values.institution_location,
            };
            userService
              .updateCertification(payload, certification.id)
              .then((data) => {
                handleClose();
                dispatch(init_certifications());
                dispatch(successAlert("Updated Successfully"));
                setTimeout(() => {
                  dispatch(errorAlert(""));
                }, 2000);
              })
              .catch((error) => dispatch(errorAlert("Problem updating!")));
          }}
        >
          {(props) => (
              <Form className="text-left m-auto" >
              <FormikTextInput name="title" placeholder="Title" />
              <FormikTextInput
                name="year_achieved"
                placeholder="Year Achieved"
              />
              <FormikTextInput name="institution" placeholder="Institution" />
              <FormikTextInput
                name="institution_location"
                placeholder="Institution Location"
              />
              <br />

              <div textAlign="text-center">
                <button
                    className="btn btn-outline-primary w-100"
                    type="submit"
                  >
                    {props.isSubmitting ? "Loading.." : "Update"}
                </button>
              </div>
            </Form>
          )}
        </Formik>
      </Modal.Body>
    </Modal>
  );
};

export default UpdateCertification;
